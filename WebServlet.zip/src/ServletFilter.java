import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class ServletFilter implements Filter { // 인터페이스형 상속
	// web.xml에 등록해 줘야함
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) 
			throws IOException, ServletException {
		System.out.println("필터1");
		req.setCharacterEncoding("UTF-8"); // 브라우저에서 받아올 때의 한글 깨짐 해결
		res.setCharacterEncoding("UTF-8"); // 서블릿에서 브라우저로 줄 때 한글 깨짐 해결
		res.setContentType("text/html; charset=UTF-8"); // 서블릿에서 브라우저로 줄 때 한글 깨짐 해결
		chain.doFilter(req, res); // 필터처리한 다음 서블릿으로 가라는 메소드(원래 나오던 화면 출력 해줌)
		System.out.println("필터2");
	}
	
}