package com.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Result")
public class Result extends HttpServlet {
	
	private final String page = "Result.jsp";
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Get왔니~!");
		int cnt = Integer.parseInt(request.getParameter("cnt")); // 문자열 cnt를 정수형으로 받기 위해 형변환 하고 정수형 변수로 받음
		String txt = request.getParameter("txt");
		System.out.println(cnt + ": " + txt);
		
		request.setAttribute("cnt", cnt); // util의 jsp쪽으로 보낼 때 request로 요청해서 보내기 때문에 request
		request.setAttribute("txt", txt);
		
		Utils.print(request, response, page);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Post왔니~!");
		int cnt = Integer.parseInt(request.getParameter("cnt")); // 문자열 cnt를 정수형으로 받기 위해 형변환 하고 정수형 변수로 받음
		String txt = request.getParameter("txt");
		System.out.println(cnt + ": " + txt);
		
		request.setAttribute("cnt", cnt); // util의 jsp쪽으로 보낼 때 request로 요청해서 보내기 때문에 request
		request.setAttribute("txt", txt);
		
		Utils.print(request, response, page);
	}

}
