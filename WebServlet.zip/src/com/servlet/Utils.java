package com.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Utils {
	
	public static void print(HttpServletRequest request, HttpServletResponse response, String page) throws ServletException, IOException {
		String root = "/WEB-INF/views/"; // 경로 중요! 맨뒤에 "/" 붙여줘야 함
//		System.out.println(root.concat(page));
		RequestDispatcher view = request.getRequestDispatcher(root.concat(page)); // concat: 문자와 문자를 합치는 메소드
		view.forward(request, response); 
	}

}
