import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Util {
	// 공통 코드를 메소드로 만들어 모두 사용할 수 있게 메모리에 올려둠(static)
	public static void ko(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); // 브라우저에서 받아올 때의 한글 깨짐 해결
		response.setCharacterEncoding("UTF-8"); // 서블릿에서 브라우저로 줄 때 한글 깨짐 해결
		response.setContentType("text/html; charset=UTF-8"); // 서블릿에서 브라우저로 줄 때 한글 깨짐 해결
	}
}
